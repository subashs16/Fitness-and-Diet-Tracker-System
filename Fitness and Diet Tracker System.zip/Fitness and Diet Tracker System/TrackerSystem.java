import java.util.*;
import java.io.*;

class User {
    private String name;
    private int age;
    private double weight;
    private double height;
    private String fitnessGoal;
    private String workoutType;

    public User(String name, int age, double weight, double height, String fitnessGoal, String workoutType) {
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.fitnessGoal = fitnessGoal;
        this.workoutType = workoutType;
    }

    public String getName() {
        return name;
    }

    public double getWeight() {
        return weight;
    }

    public double getHeight() {
        return height;
    }

    public String getFitnessGoal() {
        return fitnessGoal;
    }

    public String getWorkoutType() {
        return workoutType;
    }

    @Override
    public String toString() {
        return "User: " + name + "\nAge: " + age + "\nWeight: " + weight + " kg\nHeight: " + height + " m\nFitness Goal: " + fitnessGoal + "\nPreferred Workout: " + workoutType;
    }
}

class TrackerSystem {
    private static List<User> users = new ArrayList<>();
    private static Map<String, List<String>> workoutPlans = new HashMap<>();
    private static Map<String, List<String>> dietPlans = new HashMap<>();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        initializePlans(); // Adding some workout and diet plans for demo purposes

        int choice;
        do {
            System.out.println("\nFitness & Diet Tracker Menu:");
            System.out.println("1. Create User Profile");
            System.out.println("2. View User Profile");
            System.out.println("3. Track Workout");
            System.out.println("4. Track Food Intake");
            System.out.println("5. View Progress");
            System.out.println("6. Get Personalized Recommendations");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    createUserProfile();
                    break;
                case 2:
                    viewUserProfile();
                    break;
                case 3:
                    trackWorkout();
                    break;
                case 4:
                    trackFoodIntake();
                    break;
                case 5:
                    viewProgress();
                    break;
                case 6:
                    getRecommendations();
                    break;
                case 7:
                    System.out.println("Exiting Fitness & Diet Tracker.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 7);
    }

    private static void createUserProfile() {
        System.out.print("Enter your name: ");
        String name = sc.nextLine();
        System.out.print("Enter your age: ");
        int age = sc.nextInt();
        System.out.print("Enter your weight (kg): ");
        double weight = sc.nextDouble();
        System.out.print("Enter your height (m): ");
        double height = sc.nextDouble();
        sc.nextLine(); // Consume the newline character
        System.out.print("Enter your fitness goal (e.g., weight loss, muscle gain): ");
        String fitnessGoal = sc.nextLine();
        System.out.print("Enter your preferred workout type (e.g., cardio, strength, yoga): ");
        String workoutType = sc.nextLine();

        User user = new User(name, age, weight, height, fitnessGoal, workoutType);
        users.add(user);

        System.out.println("User profile created successfully.");
    }

    private static void viewUserProfile() {
        if (users.isEmpty()) {
            System.out.println("No user profiles found. Please create a profile first.");
            return;
        }

        System.out.println("Enter your name to view profile: ");
        String name = sc.nextLine();
        User user = getUserByName(name);

        if (user != null) {
            System.out.println(user);
        } else {
            System.out.println("User not found.");
        }
    }

    private static void trackWorkout() {
        if (users.isEmpty()) {
            System.out.println("No user profiles found. Please create a profile first.");
            return;
        }

        System.out.print("Enter your name to log workout: ");
        String name = sc.nextLine();
        User user = getUserByName(name);

        if (user != null) {
            System.out.println("Enter workout type: ");
            String workoutType = sc.nextLine();
            System.out.println("Enter duration of the workout (in minutes): ");
            int duration = sc.nextInt();
            System.out.println("Calories burned: " + (duration * 8)); // Assuming 8 calories burned per minute of exercise
            sc.nextLine(); // Consume the newline character
        } else {
            System.out.println("User not found.");
        }
    }

    private static void trackFoodIntake() {
        if (users.isEmpty()) {
            System.out.println("No user profiles found. Please create a profile first.");
            return;
        }

        System.out.print("Enter your name to log food intake: ");
        String name = sc.nextLine();
        User user = getUserByName(name);

        if (user != null) {
            System.out.println("Enter food item: ");
            String foodItem = sc.nextLine();
            System.out.println("Enter calories for the food item: ");
            int calories = sc.nextInt();
            sc.nextLine(); // Consume the newline character
            System.out.println("Food logged: " + foodItem + " with " + calories + " calories.");
        } else {
            System.out.println("User not found.");
        }
    }

    private static void viewProgress() {
        if (users.isEmpty()) {
            System.out.println("No user profiles found.");
            return;
        }

        System.out.print("Enter your name to view progress: ");
        String name = sc.nextLine();
        User user = getUserByName(name);

        if (user != null) {
            System.out.println("Your fitness goal: " + user.getFitnessGoal());
            System.out.println("Your preferred workout type: " + user.getWorkoutType());
            System.out.println("Your current weight: " + user.getWeight() + " kg");
            // You can also calculate progress, for now it's just showing basic details
        } else {
            System.out.println("User not found.");
        }
    }

    private static void getRecommendations() {
        if (users.isEmpty()) {
            System.out.println("No user profiles found.");
            return;
        }

        System.out.print("Enter your name for personalized recommendations: ");
        String name = sc.nextLine();
        User user = getUserByName(name);

        if (user != null) {
            System.out.println("Getting recommendations for you...");
            // Provide workout and diet plan recommendations based on user's goal
            System.out.println("Recommended workouts for you: ");
            for (String workout : workoutPlans.get(user.getFitnessGoal())) {
                System.out.println(workout);
            }

            System.out.println("Recommended diet plan: ");
            for (String meal : dietPlans.get(user.getFitnessGoal())) {
                System.out.println(meal);
            }
        } else {
            System.out.println("User not found.");
        }
    }

    private static User getUserByName(String name) {
        for (User user : users) {
            if (user.getName().equalsIgnoreCase(name)) {
                return user;
            }
        }
        return null;
    }

    private static void initializePlans() {
        // Predefined workout plans based on fitness goals
        workoutPlans.put("weight loss", Arrays.asList("Running", "Cycling", "Yoga"));
        workoutPlans.put("muscle gain", Arrays.asList("Weight Lifting", "Bodyweight Exercises"));
        workoutPlans.put("general fitness", Arrays.asList("Swimming", "Walking", "Yoga"));

        // Predefined diet plans based on fitness goals
        dietPlans.put("weight loss", Arrays.asList("Low-Carb Diet", "High-Protein Diet"));
        dietPlans.put("muscle gain", Arrays.asList("High-Protein Diet", "Balanced Diet"));
        dietPlans.put("general fitness", Arrays.asList("Balanced Diet", "Vegetarian Diet"));
    }
}
